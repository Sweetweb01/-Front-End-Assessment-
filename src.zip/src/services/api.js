import axios from "axios";

const API_URL = "https://6797aa2bc2c861de0c6d964c.mockapi.io/domain";

// Fetch all domains
export const getDomains = async () => {
  try {
    const response = await axios.get(`${API_URL}`);
    return response.data;
  } catch (error) {
    console.error("Error fetching domains:", error);
    throw error;
  }
};

// Add a new domain
export const addDomain = async (domainData) => {
  try {
    const response = await axios.post(`${API_URL}`, domainData);
    return response.data;
  } catch (error) {
    console.error("Error adding domain:", error);
    throw error;
  }
};

// Update an existing domain
export const updateDomain = async (id, updatedData) => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, updatedData);
    return response.data;
  } catch (error) {
    console.error("Error updating domain:", error);
    throw error;
  }
};

// Delete a domain
export const deleteDomain = async (id) => {
  try {
    await axios.delete(`${API_URL}/${id}`);
    return true;
  } catch (error) {
    console.error("Error deleting domain:", error);
    throw error;
  }
};
