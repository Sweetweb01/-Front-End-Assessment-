export const validateDomain = (domain) => {
  const regex = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/;
  return regex.test(domain);
};

export const validateStatus = (status) => {
  return ["pending", "verified", "rejected"].includes(status);
};
