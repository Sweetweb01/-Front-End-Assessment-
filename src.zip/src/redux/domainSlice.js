import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const domainApi = createApi({
  reducerPath: "domainApi",
  baseQuery: fetchBaseQuery({ baseUrl: "https://6797aa2bc2c861de0c6d964c.mockapi.io/domain" }),
  endpoints: (builder) => ({
    getDomains: builder.query({ query: () => "/" }),
    addDomain: builder.mutation({ query: (newDomain) => ({ url: "/", method: "POST", body: newDomain }) }),
    updateDomain: builder.mutation({ query: ({ id, data }) => ({ url: `/${id}`, method: "PUT", body: data }) }),
    deleteDomain: builder.mutation({ query: (id) => ({ url: `/${id}`, method: "DELETE" }) }),
  }),
});

export const { useGetDomainsQuery, useAddDomainMutation, useUpdateDomainMutation, useDeleteDomainMutation } = domainApi;
