import { configureStore } from "@reduxjs/toolkit";
import { domainApi } from "./domainSlice";

const store = configureStore({
  reducer: {
    [domainApi.reducerPath]: domainApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(domainApi.middleware),
});

export default store;
