import React, { useState } from "react";
import { Button } from "antd";
import TableView from "../components/TableView";
import DrawerForm from "../components/DrawerForm";

const Home = () => {
  const [drawerVisible, setDrawerVisible] = useState(false);

  return (
    <div>
      <Button type="primary" onClick={() => setDrawerVisible(true)}>افزودن دامنه جدید</Button>
      <TableView />
      <DrawerForm visible={drawerVisible} onClose={() => setDrawerVisible(false)} />
    </div>
  );
};

export default Home;
