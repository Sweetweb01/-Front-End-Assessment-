import React from "react";
import { Table, Tag } from "antd";
import { useGetDomainsQuery } from "../redux/domainSlice";

const TableView = () => {
  const { data, error, isLoading } = useGetDomainsQuery();

  if (isLoading) return <p>در حال بارگیری...</p>;
  if (error) return <p>خطا در دریافت داده‌ها!</p>;

  const columns = [
    { title: "نام دامنه", dataIndex: "domain", key: "domain" },
    { title: "تاریخ ایجاد", dataIndex: "createdDate", key: "createdDate" },
    { 
      title: "وضعیت", 
      dataIndex: "status", 
      key: "status",
      render: (status) => <Tag color={status === "verified" ? "green" : status === "pending" ? "orange" : "red"}>{status}</Tag>,
    },
  ];

  return <Table dataSource={data} columns={columns} rowKey="id" />;
};

export default TableView;
