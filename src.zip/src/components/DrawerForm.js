import React, { useState } from "react";
import { Drawer, Form, Input, Switch, Button } from "antd";
import { useAddDomainMutation } from "../redux/domainSlice";

const DrawerForm = ({ visible, onClose }) => {
  const [addDomain] = useAddDomainMutation();
  const [form] = Form.useForm();

  const handleSubmit = async () => {
    const values = await form.validateFields();
    await addDomain({ ...values, createdDate: Date.now() });
    form.resetFields();
    onClose();
  };

  return (
    <Drawer title="افزودن دامنه جدید" onClose={onClose} visible={visible}>
      <Form form={form} layout="vertical">
        <Form.Item name="domain" label="نام دامنه" rules={[{ required: true, message: "نام دامنه الزامی است!" }]}>
          <Input />
        </Form.Item>
        <Form.Item name="isActive" label="فعال بودن" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item>
          <Button type="primary" onClick={handleSubmit}>ثبت</Button>
        </Form.Item>
      </Form>
    </Drawer>
  );
};

export default DrawerForm;
